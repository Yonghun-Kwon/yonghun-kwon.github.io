/**************************************************
 * RNT-NTRD  SHK
 * 2015. 3. 05 Ver.01 
 **************************************************/

#include "L298N.h"
#include "Arduino.h"

L298N::L298N(int enAPin, int en1Pin, int en2Pin, int enBPin, int en3Pin, int en4Pin)
{
	this->enAPin = enAPin;
	this->en1Pin = en1Pin;
	this->en2Pin = en2Pin;
	this->enBPin = enBPin;
	this->en3Pin = en3Pin;
	this->en4Pin = en4Pin;
	this->speed = DEF_SPEED;
}

void L298N::begin(void)
{
		pinMode(this->enAPin, OUTPUT); 
		pinMode(this->en1Pin, OUTPUT); 
		pinMode(this->en2Pin, OUTPUT);
		pinMode(this->enBPin, OUTPUT);
		pinMode(this->en3Pin, OUTPUT);
		pinMode(this->en4Pin, OUTPUT);
}


void L298N::goBack(int nSpeed)  
{
	    //this->speed =  nSpeed;
		digitalWrite(this->en1Pin, LOW);
		digitalWrite(this->en2Pin, HIGH);
		analogWrite(this->enAPin,  this->speed);

		digitalWrite(this->en3Pin, LOW);
		digitalWrite(this->en4Pin, HIGH);
		analogWrite(this->enBPin,  this->speed);
}


void L298N::goForward(int nSpeed)
{
	    //this->speed = nSpeed;
		digitalWrite(this->en1Pin, HIGH);
		digitalWrite(this->en2Pin, LOW);
		analogWrite(this->enAPin, this->speed);

		digitalWrite(this->en3Pin, HIGH);
		digitalWrite(this->en4Pin, LOW);
		analogWrite(this->enBPin, this->speed);	
}

void L298N::goLeft(void)
{
		digitalWrite(this->en1Pin, HIGH);
		digitalWrite(this->en2Pin, LOW);
		analogWrite(this->enAPin, NOR_SPEED);

		digitalWrite(this->en3Pin, LOW);
		digitalWrite(this->en4Pin, HIGH);
		analogWrite(this->enBPin, MAX_SPEED);
}

void L298N::goRight(void)
{
		digitalWrite(this->en1Pin, LOW);
		digitalWrite(this->en2Pin, HIGH);
		analogWrite(this->enAPin, MAX_SPEED);

		digitalWrite(this->en3Pin, HIGH);
		digitalWrite(this->en4Pin, LOW);
		analogWrite(this->enBPin, NOR_SPEED);
}


void L298N::stop(void)
{
		analogWrite(this->enAPin, 0);
		analogWrite(this->enBPin, 0);
}


void L298N::setSpeed(int speed)
{
		this->speed = speed;
}


int L298N::getSpeed(void)
{
		return this->speed;
}


